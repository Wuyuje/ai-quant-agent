// ═══════════════════════════════════════════════════════════
// 新量化智能体·多用户管理器 (QuantAgentManager)
// 复用一个体: 用户DB / 币安APIkey / 算力费扣款 / 多人独立
// 每个用户独立运行: 数据工具→市场分类→双策略→执行风控
// 保存原系统: 用户注册/APIkey/算力费充值+自动扣/多人互不干扰
// ═══════════════════════════════════════════════════════════
const path = require('path');
const fs = require('fs');
const { BinanceAPI } = require('../lib/common');
const { decrypt } = require('../core/crypto-utils');
const { FeatureEngineer, toArray } = require('./featurer');
const { MarketClassifier } = require('./market-classifier');
const { TrendStrategy } = require('./trend-strategy');  // MA趋势引擎(规格版)
const { TrendBandStrategy } = require('./trend-band-strategy'); // ✱真趋势波段引擎(4h, 已验证胜率48%/每笔+2.8%)
const { TradeExecutionCore } = require('./execution-core');
// V4策略已删除(用户决定移除)
const { BollingerStrategy } = require('./bollinger-strategy');
const { BrainCore } = require('./brain-core');
const { SharedMarket } = require('../lib/shared-market');  // ═══ 百万框架: 成熟共享行情(single-flight去重+缓存回退) ═══

// 算力费(与旧A策略一致): 盈利按平台0.20+生态0.10=30%扣给管理员
const PLATFORM_FEE_RATE = 0.20;
const ECO_FUND_RATE = 0.10;

class QuantAgent {
  constructor({ wallet, apiKey, apiSecret, isAdmin, isWhitelist, userDB, pauseOpen, sharedMarket, signalMap }) {
    this.wallet = wallet;
    this.isAdmin = isAdmin;
    this.isWhitelist = isWhitelist || false;
    this.userDB = userDB;
    this.sharedMarket = sharedMarket || null;   // ═══ 百万框架: 全局共享行情(所有用户共用1份K线, single-flight去重) ═══
    this.klineCache = (sharedMarket && sharedMarket._klineCache) || null;  // 兼容旧缓存引用
    this.signalMap = signalMap || null;     // ═══ 十万并发阶段2: 共享开仓信号(首个用户算,其他复用, 降低CPU) ═══
    if (typeof pauseOpen === 'boolean') this.pauseOpen = pauseOpen;
    this.api = new BinanceAPI(apiKey, apiSecret);
    this.fe = new FeatureEngineer();
    this.classifier = new MarketClassifier();
    this.trend = new TrendStrategy();  // MA多空排列趋势引擎(纯MA7, 回测一致无DIF)
    this.trendBand = new TrendBandStrategy({ period: '4h' });  // ✱真趋势波段引擎(4h, 主策略)
    this.boll = new BollingerStrategy();      // 新震荡·布林带策略
    this.brain = new BrainCore(wallet);       // 大脑中枢(切换+自学习+NN, 每用户独立持久化)
    this.executor = new TradeExecutionCore({ api: this.api, wallet, logFn: m => this._log(m) });

    this.balance = 0;
    this.totalWalletBalance = 0;   // 币安合约账户总余额(合约总资金)
    this.positions = {};       // symbol → {side, qty, entryPrice, leverage, _peak, strategy}
    this._posStrategy = {};    // symbol → 持久化开仓策略映射(重启恢复用, 防误判接管)
    this.closedHistory = [];
    this._stratLock = {};      // symbol → 锁定的策略(trend/bollinger), 防双引擎互博
    this.pauseOpen = false;
    this.BLACKLIST = ['ATOMUSDT', 'STXUSDT', 'LITUSDT', 'INJUSDT'];   // ═══ 黑名单: ATOM/STX/LIT/INJ 高频秒仓或高波动连亏, 禁交易 ═══
    // ═══ 震荡策略风控: 单日熔断 + 单币连续亏损禁开 ═══
    this._dailyLossTotal = 0;      // 当日已实现盈亏累计(用于熔断)
    this._dailyLossDate = null;    // 当前累计日期(重置用)
    this._bollCooldowns = {};      // symbol → 解禁时间戳(单币连续亏3次禁3天)
    this._runCount = 0;
    this._logTag = wallet.slice(0,10);
    // 状态文件路径: 每个用户独立持久化(closedHistory/balance), 重启不丢
    try { this._stateFile = path.join(__dirname, '..', 'data', 'users', wallet, 'quant-state.json'); fs.mkdirSync(path.dirname(this._stateFile), { recursive: true }); } catch(e){ this._stateFile = null; }
    this._loadPosStrategy();   // ═══ 重启后恢复各持仓原本的开仓策略(防布林仓被误判为trend用EMA砍掉) ═══
    this._loadState();
  }

  // ═══ 自适应资金/杠杆/持仓配置器: 按用户余额自动计算, 不硬编码 ═══
  // 所有用户(普通/白名单/管理员)统一由引擎自动算, 不需要人工配置
  // 设计原则: 小余额高杠杆少仓位盘活资金+防爆, 大余额低杠杆多仓位稳收益
  _riskProfile(balance) {
    const bal = balance || this.balance || 0;
    // ═══ 余额分级 ═══
    // 极小户(<$50): 不交易(最低门槛, 手续费就吃光)
    // 小户($50~$200): 2仓/5x杠杆/每仓20%本金 — 高杠杆盘活, 少仓位集中
    // 中户($200~$500): 3仓/4x杠杆/每仓15%本金 — 均衡
    // 大户($500~$2000): 4仓/3x杠杆/每仓12%本金 — 稳健
    // 超大户(>$2000): 5仓/2x杠杆/每仓10%本金 — 资金充裕, 低杠杆控风险
    // 管理员特殊: 杠杆固定5x(用户要求配高一档), 仓位/资金仍按余额自适应
    let maxPositions, maxPerStrategy, leverage, posPct, riskPct;
    if (bal < 50) {
      maxPositions = 0; maxPerStrategy = 0; leverage = 1; posPct = 0; riskPct = 0;
    } else if (bal < 200) {
      maxPositions = 2; maxPerStrategy = 2; leverage = 5; posPct = 0.20; riskPct = 0.02;
    } else if (bal < 500) {
      maxPositions = 3; maxPerStrategy = 3; leverage = 4; posPct = 0.15; riskPct = 0.02;
    } else if (bal < 2000) {
      maxPositions = 4; maxPerStrategy = 4; leverage = 3; posPct = 0.12; riskPct = 0.02;
    } else {
      maxPositions = 5; maxPerStrategy = 5; leverage = 2; posPct = 0.10; riskPct = 0.015;
    }
    // ═══ 管理员账户: 自动配备基础上杠杆整体调高一档(用户要求适当配高, 用自适应而非固定, 防多仓+高杠杆爆仓) ═══
    //   小户5→6x / 中户4→5x / 大户3→4x / 超大2→3x; 资金/仓位仍按余额自动分级
    const isAdmin = !!this.isAdmin && bal >= 50;
    if (isAdmin) leverage = Math.min(leverage + 1, 6);   // 调高一档, 上限6x
    const who = isAdmin ? '⚙️管理员(+1档)' : '';
    this._log(`📊 风控画像: 余额$${bal.toFixed(0)} → ${maxPositions}仓/${leverage}x杠杆/每仓${(posPct*100).toFixed(0)}%本金/风险${(riskPct*100).toFixed(1)}%${who}`);
    return { maxPositions, maxPerStrategy, leverage, posPct, riskPct, balance: bal };
  }

  // ═══ 仓位/敞口上限(自动+有上限): 每策略上限+跨策略总仓位上上限+保证金敞口熔断 ═══
  // 各账户独立用自身balance/positions计算, 互不影响
  _exposureOk(strat, rp) {
    try {
      // ═══ 用户要求: 趋势策略和布林策略 各自最多5个仓位, 互不干扰 ═══
      const perStrat = 5;              // 每策略固定最多5仓(趋势≤5, 布林≤5)
      const totalCap = 10;             // 跨策略总上限10(趋势5+布林5)
      const trendCount = Object.values(this.positions).filter(p => p.strategy !== 'bollinger').length;
      const bollCount = Object.values(this.positions).filter(p => p.strategy === 'bollinger').length;
      const totalCount = Object.keys(this.positions).length;
      const targetCount = strat === 'bollinger' ? bollCount : trendCount;
      const isBoll = strat === 'bollinger';
      if (targetCount >= perStrat) return { allow: false, reason: `${isBoll?'布林':'趋势'}持仓已达${targetCount}/${perStrat}上限` };
      if (totalCount >= totalCap) return { allow: false, reason: `账户总仓位已达上限${totalCount}/${totalCap}(趋势+布林合计)` };
      // ═══ 保证金敞口熔断: 已有持仓保证金(notional/lev) + 新仓保证金 ≤ 总权益×90% ═══
      const eq = (this.totalWalletBalance > 0 ? this.totalWalletBalance : (this.balance || 1));
      let curMargin = 0;
      for (const p of Object.values(this.positions)) {
        const lev = p.leverage || rp.leverage || 1;
        const notional = (p.entryPrice || 0) * (p.qty || 0);
        curMargin += notional / lev;
      }
      const newMargin = (this.balance || 0) * rp.posPct;   // 新仓保证金 = 余额×每仓%本金
      const marginCap = eq * 0.9;                          // 保证金占用 ≤ 总权益90%(留10%保证金缓冲)
      if ((curMargin + newMargin) > marginCap) return { allow: false, reason: `保证金敞口将超限(当前$${curMargin.toFixed(1)}+新$${newMargin.toFixed(1)}>上限$${marginCap.toFixed(1)})` };
      return { allow: true, perStrat, totalCap };
    } catch (e) { return { allow: true }; }
  }

  _log(m) { const ts = new Date().toLocaleString('sv-SE',{timeZone:'Asia/Shanghai'}); console.log(`[${this._logTag}] ${ts} ${m}`); }

  // ═══ 共享开仓信号(百万框架核心阶段2): 开仓方向判定与用户无关, 全市场只算1次, 所有用户复用 ═══
  // 共享: 趋势信号 / 布林带宽门禁(openGate) / 布林触轨信号(esig) / 布林方向门禁(gate) — 均只依赖K线
  // 不共享: brain.decide(每用户独立) / 持仓管理(每用户持仓不同) / 开仓执行(每用户自己资金)
  _getSharedOpenSignal(symbol, kl5, bkl) {
    if (this.signalMap && this.signalMap[symbol]) {
      const s = this.signalMap[symbol];
      if (s && s.t && (Date.now() - s.t < 60000)) return s;   // 60s内复用共享信号(避免每用户重算)
    }
    // miss → 本用户算(结果与用户无关), 写回共享供所有用户复用
    const trendSignal = kl5 ? this.trendBand.entrySignal(kl5) : null;
    const openGate = bkl ? this.boll.canOpen(bkl) : null;
    const esig = bkl ? this.boll.entrySignal(bkl, 'FLAT', false) : null;
    const gate = (bkl && esig && (esig.signal === 'LONG' || esig.signal === 'SHORT')) ? this.boll.trendDirGate(bkl, esig.signal, 3) : null;
    const sig = { trendSignal, openGate, esig, gate, t: Date.now() };
    if (this.signalMap) this.signalMap[symbol] = sig;
    return sig;
  }

  // ═══ 共享K线(百万框架核心): 所有用户共用1份K线, single-flight去重, 避免重复拉取爆Binance API ═══
  // 优先走 manager 的 SharedMarket(成熟: 并发去重+缓存回退), miss 才实际请求; ag告无SharedMarket则走自建缓存
  async _getKlinesShared(symbol, interval, limit) {
    if (this.sharedMarket) return this.sharedMarket.getKlines(symbol, interval, limit);  // SharedMarket: 共享+single-flight+回退
    if (!this.klineCache) return this.api.getKlines(symbol, interval, limit);   // 无缓存(单机)直接请求
    const key = symbol + ':' + interval + ':' + limit;
    const ttl = ({ '5m':15000, '15m':20000, '4h':30000, '1d':300000 })[interval] || 20000;
    const now = Date.now();
    const c = this.klineCache[key];
    if (c && (now - c.t < ttl)) return c.data;   // 缓存命中
    try {
      const data = await this.api.getKlines(symbol, interval, limit);
      this.klineCache[key] = { t: now, data };
      return data;
    } catch (e) {
      if (c) return c.data;   // 失败回退旧缓存
      throw e;
    }
  }
  // ═══ 持仓策略持久化: symbol → 开仓策略(ma7/v4/bollinger). 重启后由原策略继续管理, 不再靠inTrend误判接管 ═══
  _saveState() { try { const posMap = {}; for (const [sym, p] of Object.entries(this.positions)) { if (p && p.strategy) posMap[sym] = { strategy: p.strategy, side: p.side, qty: p.qty, entryPrice: p.entryPrice, leverage: p.leverage }; } fs.writeFileSync(this._stateFile, JSON.stringify({ closedHistory: this.closedHistory, balance: this.balance, positions: posMap }, null, 1)); } catch(e){} }
  // 重启后恢复持仓策略归属(只存策略映射, 不直接重建持仓, 真正head由币安同步)
  _loadPosStrategy() { try { if (fs.existsSync(this._stateFile)) { const st = JSON.parse(fs.readFileSync(this._stateFile,'utf8')); if (st && st.positions) this._posStrategy = st.positions; } } catch(e){} this._posStrategy = this._posStrategy || {}; }
  _loadState() { try { if (fs.existsSync(this._stateFile)) { const st = JSON.parse(fs.readFileSync(this._stateFile,'utf8')); if (Array.isArray(st.closedHistory)) {
    // 合理性过滤: 单笔|pnl|超本金1.5倍(物理不可能, 旧_estimatePnl公式污染) → 丢弃
    const bal = typeof st.balance==='number' && st.balance>0 ? st.balance : this.balance;
    const thr = Math.max(30, bal*1.5);
    this.closedHistory = st.closedHistory.filter(c => !c.pnl || Math.abs(c.pnl) <= thr);
    if (this.closedHistory.length < st.closedHistory.length) this._log(`⚠️ 过滤${st.closedHistory.length-this.closedHistory.length}笔异常平仓(旧盈亏公式污染), 保留${this.closedHistory.length}笔`);
  } if (typeof st.balance==='number') this.balance = st.balance; } } catch(e){} }

  // 大盘过滤器: BTC走弱(RISK)时不开新仓, 只管理已有持仓
  _btcRegime(btcKlines) {
    try {
      const arr = toArray(btcKlines); const closes = arr.map(k => +k[3]);
      if (!closes.length) return 'OK';
      const last = closes[closes.length-1];
      const seg = closes.slice(-30); const ma30v = seg.reduce((a,b)=>a+b,0)/seg.length;
      const last6 = closes[Math.max(0,closes.length-6)];
      const mom = (last-last6)/(last6||1)*100;
      const pos300 = (last-ma30v)/(ma30v||1)*100;
      if (pos300 < -0.5 && mom < -0.1) return 'DOWN';   // BTC走弱=下跌
      if (pos300 > 0.5 && mom > 0.1) return 'UP';       // BTC走强=上涨
      return 'OK';
    } catch(e){ return 'OK'; }
  }


  // ═══ 从币安同步真实持仓(引擎内存与币安一致) ═══
  async _syncPositions() {
    try {
      const acc = await this.api._request('GET', '/fapi/v2/positionRisk').catch(() => null);
      if (!Array.isArray(acc)) { if(this.isAdmin&&this._diagOnce!==1){this._diagOnce=1;this._log(`⚠️sync诊断: positionRisk非数组/null(拉取失败), 无法载入真实持仓`);} return; }
      if(this.isAdmin&&this._diagOnce!==2){this._diagOnce=2;this._log(`✅sync诊断: positionRisk拉到${acc.length}条, 真实持仓${acc.filter(p=>Math.abs(+p.positionAmt)>0).length}个`);}
      const real = acc.filter(p => p.symbol && p.positionAmt && Math.abs(+p.positionAmt) > 0);
      this._unrealizedPnl = real.reduce((s, p) => s + (+p.unRealizedProfit || 0), 0);
      for (const p of real) {
        const sym = p.symbol;
        const amt = +p.positionAmt;
        const side = amt > 0 ? 'LONG' : 'SHORT';
        // 币安有仓但引擎没记录 → 载入(接管)
        if (!this.positions[sym]) {
          const lev = parseInt(p.leverage) || 5;
          // ═══ 接管仓归属判定: 优先用持久化的开仓策略(布林仓永远是布林), 防重启后布林仓被误判为trend而被EMA砍掉 ═══
          // 持久化映射来自 _posStrategy (开仓时写入, 重启从quant-state.json加载)
          const persisted = this._posStrategy[sym];
          const inTrend = (this.MA7_POOL && this.MA7_POOL.includes(sym));
          let strat;
          if (persisted && persisted.strategy) {
            strat = persisted.strategy;                                // 原策略继续管理(ma7/v4/bollinger)
          } else {
            strat = inTrend ? 'trend' : 'bollinger';                   // 无记录才兜底猜(历史存量仓)
          }
          // 将兜底'trend'归一: 趋势接管统一为ma7(管理分支一致), 且仅当确无持久化记录才允许
          if (strat === 'trend' && !persisted) strat = 'ma7';
          // ═══ v11修复: 重启后同步到的仓标记 adoptGraceUntil(宽限期) ═══
          // 原因: HYPE 亏损平仓事故 — 重启后无持久记录 → 标 _managed=true → 被接管分支用
          //       真趋势波段止损砍掉(-3.00%)。现改为: 同步仓 30 分钟内不检查止损,
          //       避免重启瞬间被宽ATR判定/边缘价格扫掉。
          this.positions[sym] = {
            symbol: sym, side, qty: Math.abs(amt), entryPrice: +p.entryPrice,
            currentPrice: +p.markPrice, margin: Math.abs(+p.entryPrice)*(+p.markPrice)/lev,
            leverage: lev, _peak: +p.entryPrice, openTime: Date.now(),
            strategy: strat,
            _managed: !persisted,                       // 无记录=接管仓
            _adoptGrace: Date.now() + 1800000          // v11: 接管仓30分钟止损宽限期
          };
          // 同步回持久化, 防止重复误判
          this._posStrategy[sym] = { strategy: strat, side, qty: Math.abs(amt), entryPrice: +p.entryPrice, leverage: lev };
          this._saveState();
        } else {
          // 已有记录, 更新价格/数量
          this.positions[sym].currentPrice = +p.markPrice;
          const realQty = Math.abs(amt);
          if (Math.abs(realQty - (this.positions[sym].qty||0)) > (this.positions[sym].qty||0)*0.01) this.positions[sym].qty = realQty;
        }
      }
      // 币安已平的仓(本地还有) → 移除
      const realSyms = new Set(real.map(p=>p.symbol));
      for (const sym of Object.keys(this.positions)) {
        // v11.2: 清理无效 symbol(undefined/null/空) + 币安已平的仓
        if (!sym || sym === 'undefined' || sym === 'null' || !realSyms.has(sym)) {
          delete this.positions[sym]; delete this._stratLock[sym];
        }
      }

      // ═══ 币安真实已实现盈亏(30天): 缓存每5分钟拉一次, 避免频繁命中币安限速 ═══
      // 仪表盘显示这个值, 与币安App实时同步(不会被引擎内部closedHistory遗漏) ═══
      if (!this._pnlCache || Date.now() - this._pnlCache.t > 300000) {
        try {
          const start = Date.now() - 30 * 86400000;
          const inc = await this.api.getIncome(start, Date.now(), 'REALIZED_PNL').catch(() => null);
          const arr = Array.isArray(inc) ? inc : [];
          const total = arr.reduce((s, i) => s + (+i.income || 0), 0);
          // 也统计交易手续费(COMMISSION)做综合成本参考
          const comm = await this.api.getIncome(start, Date.now(), 'COMMISSION').catch(() => null);
          const commArr = Array.isArray(comm) ? comm : [];
          const fee = commArr.reduce((s, i) => s + (+i.income || 0), 0);
          this._realizedPnl30d = { total: +total.toFixed(2), trades: arr.length, commission: +fee.toFixed(2), t: Date.now() };
          this._pnlCache = { t: Date.now() };
        } catch (e) { }
      }
    } catch(e){}
  }


  // 主扫描: 每个标的
  async scan(pool) {
    await this._syncPositions();  // 先同步币安真实持仓
    // ═══ 普通用户算力费充值门槛: 记账余额<5U时停止开新仓(只管理已有持仓) ═══
    if (!this.isAdmin && !this.isWhitelist) {
      const feeInfo = this._getComputeFeeBalance();
      if (feeInfo.feeBalance < 5) {
        if (this._lastFeeBlockLog !== feeInfo.feeBalance.toFixed(2)) {
          this._log(`⛔ ${this._logTag} 算力费余额$${feeInfo.feeBalance.toFixed(2)}<5U, 停止开新仓(用户需充值)`);
          this._lastFeeBlockLog = feeInfo.feeBalance.toFixed(2);
        }
        this._manageOnly();  // 只管理已有持仓(可平仓), 不开新仓
        return;
      }
    }
    if (this.pauseOpen) { this._manageOnly(); return; }
    // 大盘过滤: 缓存BTC状态(每轮查一次)
    try {
      if (!this._btcCache || Date.now() - this._btcCache.t > 60000) {
        const bkl = await this._getKlinesShared('BTCUSDT', '4h', 60).catch(() => null);
        this._btcCache = { t: Date.now(), state: bkl ? this._btcRegime(bkl) : 'OK' };
      }
      this._marketRisk = this._btcCache.state;
    } catch(e){ this._marketRisk = 'OK'; }
    // ① 刷新余额
    try { const bal = await this.api.getBalance(); if (typeof bal === 'number') this.balance = bal; } catch(e){}
    // 合约账户总余额(总资金) 从 /fapi/v2/account 读取
    try { const acc = await this.api._request('GET', '/fapi/v2/account').catch(() => null); if (acc && acc.totalWalletBalance != null) this.totalWalletBalance = +acc.totalWalletBalance; } catch(e){}

    // ② 逐币分析: 分类市场 → 选策略 → 信号
    for (const symbol of pool) {
      try {   // ═══ 逐币容错: 一个币处理出错不中断整轮scan ═══
      // ═══ 黑名单: 排除禁区币(如ATOMUSDT高频秒仓连亏) ═══
      if (this.BLACKLIST && this.BLACKLIST.includes(symbol)) continue;
      // 已有仓位 → 交给平仓管理(趋势移动止损/网格离场)
      if (this.positions[symbol]) continue;
      // ═══ 实时选币: 不硬性限制只开优选池, 所有币都实时评估开仓 ═══
      // 开仓顺序由 rankedPool 保证(趋势Top5优先扫描, 排名靠前先开仓)
      // 若优先后右币, 其他币也实时尝试开仓(不空仓)

      const kl = await this._getKlinesShared(symbol, '15m', 300).catch(() => null);   // 300根够MA7 lookback(288)算位置区间
      if (this.isAdmin && (this._runCount % 1 === 0)) this._log(`🔍scan ${symbol}: kl=${kl?(kl.length||0):'null'}枚`);
      if (!kl || kl.length < 288) { if (this.isAdmin) this._log(`  ⏭️ ${symbol} 数据不足(kl=${kl?(kl.length||0):0})`); continue; }
      // 资金费率
      let fr = 0; try { const f = await this.api.getFundingRate(symbol); fr = Array.isArray(f)&&f[0] ? +f[0].fundingRate : 0; } catch(e){}
      // ═══ 大脑中枢: 提供市场分类/方向(不再用它的'none'拦截池内币) ═══
      const decision = this.brain.decide(symbol, kl);
      // ═══ 市场状态识别+策略自动切换(方案): trending→趋势策略顺势, ranging→布林高抛低吸, shock→观察 ═══
      const mst = (decision.market && decision.market.state) || 'ranging';
      const tdir = (decision.market && decision.market.trendDir) || 'FLAT';
      // 剧烈波动(shock)或强势下跌趋势中布林不追多: 观察
      let strat;
      if (mst === 'shock') { if (this.isAdmin) this._log(`⚡ ${symbol} 剧烈波动(shock)观望`); continue; }
      if (mst === 'trending') strat = 'trend_ma7';     // 趋势市 → 趋势策略(顺势做多/空)
      else {
        // ═══ 震荡策略只交易优选币池(回测验证正期望14币), 避免亏损山寨币拖累 ═══
        if (!(this.BOLL_PREFERRED && this.BOLL_PREFERRED.includes(symbol))) {
          if (this.isAdmin) this._log(`⏭️ ${symbol} 不在优选震荡币池, 震荡策略跳过`);
          continue;
        }
        strat = 'bollinger';                          // 震荡市 → 布林(高抛低吸)
      }
      if (this.isAdmin) this._log(`🔍分池 ${symbol}: 市场=${mst} 方向=${tdir} → ${strat}`);
      // ═══ 仓位配额: 每策略+总仓位上上限+保证金敞口 由 _exposureOk 统一管控(自动按余额分级, 防超限) ═══
      const rp = this._riskProfile(this.balance);  // 杠杆/资金比例仍按余额自适应
      // 每币单一策略锁: 已锁定则强制一致
      if (this._stratLock[symbol] && this._stratLock[symbol] !== strat) continue;

      const pm = this.sharedMarket ? await this.sharedMarket.getExchangeInfo().catch(()=>null) : await this.api.getExchangeInfo().catch(()=>null);
      
      const price = +toArray(kl)[kl.length-1][3];
      let sig;
      if (strat === 'trend_ma7') {
        if (this.pauseTrend) continue;   // 趋势引擎暂停开仓
        if (this.positions[symbol]) continue;   // 同币已持单, 不再开
        // ═══ 分开选池: 币在MA7池只跑MA7(15m), 在V4池只跑V4(日线) ═══
        let sig = null, stg = 'ma7';
        let kl5 = null;   // 提前声明, 供下方闸门/贴线判断统一使用(修复kl5块级作用域丢失bug)
        {
          // ═══ 真趋势波段(4h): EMA排列+破60前高低+动量确认, 宽止损/高止盈 (共享信号, 不每用户重算) ═══
          kl5 = await this._getKlinesShared(symbol, '4h', 300).catch(() => null);
          sig = this._getSharedOpenSignal(symbol, kl5 || kl, null).trendSignal || null;
        }
        if (!sig || sig.signal === 'NONE') {
          // ═══ 市场状态分池: 趋势市(trending)趋势无信号→直接跳过, 不再落布林(防布林在趋势市逆势抄底); 布林只在震荡市走bollinger分支 ═══
          if (this.isAdmin) this._log(`⏭️ ${symbol} 趋势市无趋势信号, 跳过(不落布林)`);
          continue;
        }
        // ═══ 实时市场健康闸门: 当下ADX/ATR校验(根治假波动币, 趋势只碰真单边) ═══
        const gate = this._marketGate('trend', kl5 || kl);
        if (gate) { if (this.isAdmin) this._log(`🚫 ${symbol} ${stg}禁开: ${gate}`); continue; }
        // ═══ 大级别方向闸门(EMA200同向): 防EMA及V4把趋势开反(方案2只留EMA200, 保留更多开仓且防逆势) ═══
        if (stg === 'ma7' && sig && (sig.signal === 'LONG' || sig.signal === 'SHORT')) {
          const alignBlock = await this._trendAlignGate(symbol, sig.signal, stg === 'ma7' ? (kl5 || kl) : kl).catch(() => null);
          if (alignBlock) { if (this.isAdmin) this._log(`🚫 ${symbol} ${stg}反大趋势禁开: ${alignBlock}`); continue; }
        }
        // ═══ 贴EMA99禁开仓: 真趋势波段用ATR宽止损不用贴线; V4已删除 ═══
        this._log(`🔍 ${symbol} ${stg}信号=${sig.signal} 准备开仓`);
        // ═══ 仓位: 真趋势波段(4h) 用波动率目标 + 自适应资金配置(按余额算posPct/riskPct/leverage) ═══
        const posPct = rp.posPct;
        const lev = rp.leverage;                      // 自适应杠杆(小户5x/中户4x/大户3x/超大户2x)
        const riskPct = rp.riskPct;                   // 单笔风险占本金比(小/中/大户2%, 超大户1.5%)
        let bs;
        {
          const atr = sig.atr;
          let notional;
          if (atr && atr > 0) {
            const risk = this.balance * riskPct;             // 单笔风险=riskPct%本金
            const stopDist = this.trendBand.stopMul * atr;  // 止损距离USD
            notional = Math.max(this.balance * posPct, Math.min(this.balance * (posPct*4), risk / (stopDist / (price || 1)) ));
          } else {
            notional = this.balance * posPct;
          }
          bs = { notional };
        }
        if ((this.balance || 0) < 50) continue;
        // ═══ 仓位/敞口上限(自动按余额分级): 每策略上限+总仓位上上限+保证金熔断 ═══
        const capOkT = this._exposureOk('trend', rp);
        if (!capOkT.allow) { if (this.isAdmin) this._log(`⏸️ ${symbol} 趋势不开新仓: ${capOkT.reason}`); continue; }
        const r = await this.executor.executeOrder(sig, { symbol, side: sig.signal, notional: bs.notional, leverage: lev, precisionMap: pm, price, balance: this.balance });
        if (r.success) { this.positions[symbol] = { side: sig.signal, qty: r.qty, entryPrice: price, leverage: lev, strategy: stg, _t: '4h', _peak: price, _best: price, openTime: Date.now() }; this._stratLock[symbol]=stg; this._saveState(); }
      } else if (strat === 'bollinger') {
        // 多币并仓: 震荡池全部币可开(不限bollTop前5, 提高资金使用)
        if (this.pauseBoll) continue;   // 暂停震荡(布林)策略开仓
        // ═══ 单日亏损熔断: 当日累计亏损≥5%本金 → 全面暂停开仓, 防极端行情累积 ═══
        { const today = new Date().toISOString().slice(0,10);
          if (this._dailyLossDate !== today) { this._dailyLossDate = today; this._dailyLossTotal = 0; }
          if (Math.abs(this._dailyLossTotal) >= this.balance * 0.05 && this._dailyLossTotal < 0) {
            if (this.isAdmin) this._log(`⛔ 布林日亏损熔断: 累计$${this._dailyLossTotal.toFixed(2)}≥5%本金$${(this.balance*0.05).toFixed(2)}, 暂停开仓`);
            continue;
          }
        }
        // ═══ 单币冷却禁开: 近3次亏损则禁开3天 ═══
        if (this._bollCooldowns[symbol] && Date.now() < this._bollCooldowns[symbol]) {
          if (this.isAdmin) this._log(`⏸️ ${symbol} 冷却禁开(连续亏损, 解禁时间${new Date(this._bollCooldowns[symbol]).toLocaleTimeString('zh-CN')})`);
          continue;
        }
        // SuperTrend反转策略(5分钟级别): 5m K线决策(用户要求5分钟执行买卖) ═══
        const bkl = await this._getKlinesShared(symbol, '5m', 500).catch(() => null);
        if (!bkl || bkl.length < 40) continue;
        // 截图: 特殊时间(资金费率结算前15min等)禁新开/补
        const guard = this.boll.tradingGuardAllowed(bkl);
        if (!guard.allowed) continue;
        // ═══ 共享开仓信号(百万框架): 带宽门禁/触轨/方向门禁 由全局共用1份, 不每用户重算 ═══
        const shSig = this._getSharedOpenSignal(symbol, null, bkl);
        const openGate = shSig.openGate;
        if (!openGate || !openGate.allowed) continue;   // 带宽>90%禁开 / 未解禁
        const esig = shSig.esig;
        if (!esig || (esig.signal !== 'LONG' && esig.signal !== 'SHORT')) continue;
        const tg = shSig.gate;
        if (!tg || !tg.allowed) { if (this.isAdmin) this._log(`🚫 ${symbol} 布林门禁: ${tg ? tg.reason : '无门禁'}`); continue; }
        // 用门禁确认的方向开仓(与趋势一致)
        // ═══ 仓位/敞口上限(自动按余额分级) ═══
        const capOk2 = this._exposureOk('bollinger', rp);
        if (!capOk2.allow) { if (this.isAdmin) this._log(`⏸️ ${symbol} 布林不开新仓: ${capOk2.reason}`); continue; }
        const bs = { notional: Math.max(20, this.balance*rp.posPct*3), margin: Math.max(20,this.balance*rp.posPct*3)/rp.leverage, leverage: rp.leverage };
        const r = await this.executor.executeOrder(esig, { symbol, side: tg.side, notional: bs.notional, leverage: rp.leverage, precisionMap: pm, price, balance: this.balance });
        if (r.success) { this.positions[symbol] = { side: tg.side, qty: r.qty, entryPrice: price, leverage: rp.leverage, strategy: 'bollinger', _peak: price, _addRound: 0, _lastAddIdx: 0, openTime: Date.now() }; this._stratLock[symbol]='bollinger'; this._saveState(); this._log(`🔥 ${symbol} 布林顺势${tg.side}开仓(${tg.reason})`); }
      }
      } catch(e) { if (this.isAdmin) this._log(`⚠️ ${symbol} 扫描出错(跳过): ${e.message}`); }
    }
    this._manageOnly();
  }

  // 管理持仓: 移动止损/网格离场/止盈止损
  async _manageOnly() {
    for (const symbol of Object.keys(this.positions)) {
      const pos = this.positions[symbol];
      try {
        // 接管仓(启动时从币安同步的存量仓,_managed=true): 参与正常止盈/止损管理
        //  (原逻辑"接管仓一律不平仓"导致深套仓如 ENA -107% 一直不平; 现改为正常管理)
        // 保留: 不做无谓的频繁平仓, 但止损/止盈规则正常生效
        const kl = await this._getKlinesShared(symbol, '15m', 60).catch(() => null);
        if (!kl || kl.length < 20) continue;
        const price = +toArray(kl)[kl.length-1][3];
        pos.currentPrice = price;
        const pm = this.sharedMarket ? await this.sharedMarket.getExchangeInfo().catch(()=>null) : await this.api.getExchangeInfo().catch(()=>null);

        // ═══ v11修复: 接管仓宽限期 — 重启后30分钟内不检查止损/止盈 ═══
        // 原因: HYPE 亏损平仓事故 — 引擎重启后同步到的存量仓被立即用宽ATR判定扫出(-3.00%)。
        // 宽限期内只更新价格, 不执行任何平仓逻辑, 避免重启瞬间误平。
        if (pos._adoptGrace && Date.now() < pos._adoptGrace) {
          if (this.isAdmin && !pos._graceLogged) {
            pos._graceLogged = true;
            const left = Math.round((pos._adoptGrace - Date.now())/60000);
            this._log(`⏳ ${symbol}${pos._managed?'[接管]':''} 重启宽限期(${left}分), 暂不检查止损`);
          }
          continue;
        }
        let closeReason = null, pnlToCount = null;

        // ═══ 硬止损兵底: 持仓 ROI ≤ -40% 时强制平仓(防深套/爆仓) ═══
        //  ROI = 价格变动% × 杠杆; 例: 5x 杠杆价格跌8% → ROI -40% → 平仓
        {
          const _lev = pos.leverage || 1;
          const _pxPct = pos.side==='LONG' ? (price-pos.entryPrice)/pos.entryPrice*100 : (pos.entryPrice-price)/pos.entryPrice*100;
          const _roi = _pxPct * _lev;
          const HARD_SL_ROI = -40;
          // 仅在未被其他规则平仓时兜底
          if (!closeReason && _roi <= HARD_SL_ROI) {
            closeReason = `止损(硬止损ROI${_roi.toFixed(0)}%≤${HARD_SL_ROI}%)`;
          }
        }

        // V4策略已物理删除: v4持仓不再单独管理(不应存在v4仓; 若历史遗留则交由trendBand兜底不平)
        if (pos.strategy === 'ma7') {
          // ✱真趋势波段(4h): 0.6ATR止损 + 两阶段锁利
          const mkl = await this._getKlinesShared(symbol, pos._t || '4h', 200).catch(() => null);
          if (mkl && mkl.length >= 40) {
            const mArr = mkl.map(k => ({ open: +k.open, high: +k.high, low: +k.low, close: +k.close, volume: k.volume }));
            const closes = mArr.map(k => +k.close);
            const price = closes[closes.length - 1];
            const highs = mArr.map(k => +k.high);
            const lows = mArr.map(k => +k.low);
            const mg = this.trendBand.manage(pos, price, closes, highs, lows);
            if (mg.action === 'CLOSE') closeReason = mg.reason;
          }
        }
        if (pos.strategy === 'bollinger') {
          // SuperTrend反转·出场(5m): SUPER翻转平仓(checkTakeProfit), 仅保留极端兜底
          const bkl = await this._getKlinesShared(symbol, '5m', 500).catch(() => null);
          if (bkl && bkl.length >= 30) {
            const spike = this.boll.isSpikeBar(bkl);
            const tp = this.boll.checkTakeProfit(pos, bkl);
            if (tp.action === 'CLOSE' && !spike) closeReason = tp.reason;   // 插针不触发(防毛刺假平)
            else if (spike) closeReason = null;  // 插针K线不平仓(收盘回归)
            // 极简保险: 总浮亏≥50%强平(唯一兜底, 防极端行情失控)
            if (!closeReason) {
              const tpn = pos.side==='LONG' ? (price-pos.entryPrice)/pos.entryPrice*100 : (pos.entryPrice-price)/pos.entryPrice*100;
              if (Math.abs(tpn) >= 50) closeReason = `极端兜底强平(浮亏${tpn.toFixed(0)}%)`;
            }
          }
        }

        if (pos.strategy === 'trend' || (pos.strategy === 'ma7' && pos._managed)) {
          // ✱接管/存量仓: 用真趋势波段(4h) 宽ATR止损/高止盈/移动止盈 统一管理,
          // 不再用旧EMA7/25即时反转(那会一秒砍掉刚接管的仓). 布林接管仓也不误杀。
          const tf = pos._t || '4h';
          const mkl = await this._getKlinesShared(symbol, tf, 200).catch(() => null);
          if (mkl && mkl.length >= 40) {
            const mArr = mkl.map(k => ({ open: +k.open, high: +k.high, low: +k.low, close: +k.close, volume: k.volume }));
            const closes = mArr.map(k => +k.close);
            const price = closes[closes.length - 1];
            const highs = mArr.map(k => +k.high);
            const lows = mArr.map(k => +k.low);
            const mg = this.trendBand.manage(pos, price, closes, highs, lows);
            if (mg.action === 'CLOSE') closeReason = mg.reason;
          }
        }

        if (closeReason) {
          // 止损/极端保护类平仓不受净回报拦截(否则亏损没法止损); 仅"止盈/锁利"需要净回报>0校验
          const isExtreme = /极端|兜底|强平|止损/.test(closeReason || '');
          let estPnl = this._estimatePnl(pos, price);
          if (!isExtreme) {
            // ═══ 平仓前净回报校验(v11.4修正): 扣除全部费用后净回报>MIN_NET_PROFIT才允许平仓 ═══
            // 修正原因(UNI事故): 原费率0.04%低估2.6倍(实际~0.103%), 导致"移动止盈锁利"时
            //   毛利$0.07看起来>手续费$0.035, 实际净亏-$0.02。
            const takerFeeRate = 0.0011;   // v11.4: 实际双边费率约0.11%(0.055%×2, 含滑点余量)
            const MIN_NET_PROFIT = 0.03;   // v11.4: 最小净盈利$0.03, 低于此不平仓(等更大利润或反向止损)
            const grossNotional = Math.abs(pos.entryPrice * (pos.qty || 0));   // 名义价值(保证金×杠杆)
            const tradingFee = grossNotional * takerFeeRate;                   // 开+平手续费
            const isComputeFeeUser = !this.isAdmin && !this.isWhitelist;       // 普通用户才扣算力费
            let computeFee = 0;
            if (isComputeFeeUser && estPnl > 0) {
              // 算力费 = 盈利 × (平台0.20+生态0.10)=30% (普通用户)
              const cfRate = PLATFORM_FEE_RATE + ECO_FUND_RATE;                 // 0.30
              computeFee = estPnl * cfRate;
            }
            const netReturnUsd = estPnl - tradingFee - computeFee;   // 扣手续费+算力费后的净回报(USD)
            if (netReturnUsd < MIN_NET_PROFIT) {
              // 净回报不足 → 取消平仓, 持有等更大盈利或反向止损
              if (this.isAdmin) this._log(`⏸️ ${symbol} 平仓拦截: 净回报$${netReturnUsd.toFixed(3)}<$${MIN_NET_PROFIT}(毛利$${estPnl.toFixed(3)}-手续费$${tradingFee.toFixed(4)}${computeFee?`-算力费$${computeFee.toFixed(3)}`:''}), 暂不平继续持有`);
              closeReason = null;   // 取消这次平仓
            }
          }
        }
        if (closeReason) {
          pnlToCount = this._estimatePnl(pos, price);
          const r = await this.executor.closePosition(symbol, pos.side, pos.qty, pm, closeReason, pnlToCount);
          if (r.success) {
            this._settleServiceFee(symbol, pnlToCount);
            this.closedHistory.unshift({ symbol: symbol.replace('USDT',''), side: pos.side, pnl: pnlToCount, reason: closeReason, ts: Date.now(), strat: pos.strategy });
            // ═══ 单日亏损累计 + 单币连续亏损追踪(布林策略专用) ═══
            if (pos.strategy === 'bollinger' && pnlToCount < 0) {
              this._dailyLossTotal = (this._dailyLossTotal || 0) + pnlToCount;
              // 统计该币近3笔bollinger亏损次数
              const recentBoll = this.closedHistory.filter(c => c.symbol === symbol.replace('USDT','') && c.strat === 'bollinger').slice(0, 3);
              const consecutiveLoss = recentBoll.filter(c => c.pnl < 0).length;
              if (consecutiveLoss >= 3) {
                const cooldownEnd = Date.now() + 3 * 24 * 3600 * 1000;  // 禁开3天
                this._bollCooldowns[symbol] = cooldownEnd;
                this._log(`🚫 ${symbol} 布林连续${consecutiveLoss}次亏损, 禁开3天(至${new Date(cooldownEnd).toLocaleString('zh-CN')})`);
              }
            }
            // ═══ 大脑中枢自学习：每次平仓喂给神经网络+UCB绩效(用真实市场特征,不用随机数) ═══
            try {
              const notional = (pos.entryPrice || 0) * (pos.qty || 0);
              const pnlPct = notional > 0 ? (pnlToCount / notional) * 100 : 0;
              let marketFeat = null;
              try {
                const fkl = await this._getKlinesShared(symbol, '15m', 60).catch(() => null);
                if (fkl && fkl.length >= 30) {
                  const j = this.classifier.judgeMarketState(fkl, 0);
                  marketFeat = [ j.volatility*100, j.trendStrength/100, j.maConverge!=null?j.maConverge*5:0.5, j.fundingRate*1000, j.trendDir==='UP'?1:(j.trendDir==='DOWN'?-1:0) ];
                }
              } catch(e3){}
              this.brain.recordResult(symbol.replace('USDT',''), pos.strategy || 'ma7', pnlPct, marketFeat);
            } catch(e2){}
            this._saveState();  // 平仓后持久化统计
            delete this.positions[symbol];
            delete this._stratLock[symbol];  // 平仓后释放策略锁
          }
        }
      } catch(e){ this._log(`⚠️ ${symbol} 管理异常: ${e.message.slice(0,40)}`); }
    }
  }

  _estimatePnl(pos, price) {
    // 正确合约真实盈亏(近似,不含手续费): 方向价差(USD) × 币数量
    // LONG: (exit-entry)*qty ; SHORT: (entry-exit)*qty
    // 注: 不能除以entry(那会把金额放大几百倍, 出过 -$329超本金的bug)
    const dir = pos.side === 'LONG' ? (price - pos.entryPrice) : (pos.entryPrice - price);
    return dir * (pos.qty || 0);
  }

  // 算力费扣款(普通用户盈利扣30% → 管理员钱包累计)
  // ═══ 读取普通用户算力费记账余额(充值余额, 供停止开仓判断) ═══
  _getComputeFeeBalance() {
    try {
      const userFile = path.join(__dirname, '..', 'data', 'saas-users.json');
      const all = JSON.parse(require('fs').readFileSync(userFile,'utf8'));
      const wl = (this.wallet || '').toLowerCase();
      const key = Object.keys(all).find(k => k.toLowerCase() === wl);
      const bal = key && all[key] ? (+(all[key].gatesFeeBalance || 0)) : 0;
      return { feeBalance: bal, key: key || wl };
    } catch(e) { return { feeBalance: 5, key: '' }; }  // 读不到返回5(放行,避免误停)
  }

  _settleServiceFee(symbol, pnlUsd) {
    if (!pnlUsd || pnlUsd <= 0 || this.isAdmin || this.isWhitelist) return;   // 管理员/白名单免算力费
    const platformFee = pnlUsd * PLATFORM_FEE_RATE;
    const ecoFund = pnlUsd * ECO_FUND_RATE;
    const feeTotal = platformFee + ecoFund;
    try {
      const feeFile = path.join(__dirname, '..', 'data', 'quant-fee-state.json');
      let st = {}; try { st = JSON.parse(require('fs').readFileSync(feeFile,'utf8')); } catch(e){ st = { totalPlatform:0, totalEco:0, pending:{} }; }
      st.totalPlatform = (st.totalPlatform||0) + platformFee;
      st.totalEco = (st.totalEco||0) + ecoFund;
      st.pending = st.pending || {}; st.pending[this.wallet] = (st.pending[this.wallet]||0) + feeTotal;
      require('fs').writeFileSync(feeFile, JSON.stringify(st, null, 2));
    } catch(e){}
    // 写回 saas-users.json 的用户算力费余额(gatesFeeBalance), 供普通用户仪表盘显示扣减
    try {
      const userFile = path.join(__dirname, '..', 'data', 'saas-users.json');
      const all = JSON.parse(require('fs').readFileSync(userFile,'utf8'));
      const wl = this.wallet.toLowerCase();
      const key = Object.keys(all).find(k => k.toLowerCase() === wl) || wl;
      if (all[key]) {
        const oldBal = all[key].gatesFeeBalance || 0;
        all[key].gatesFeeBalance = oldBal - feeTotal;
        all[key].gatesFeeLow = (oldBal - feeTotal) < 5;
        require('fs').writeFileSync(userFile, JSON.stringify(all, null, 2));
      }
    } catch(e){}
    this._log(`💰 ${symbol} 扣算力费$${feeTotal.toFixed(2)}(平台${platformFee.toFixed(2)}+生态${ecoFund.toFixed(2)}) 记账到管理员(待授权转账)`);
    // ═══ 不再自动链上转账: 算力费累计记账到quant-fee-state.json, 由管理员用新钱包手动授权转账到PLATFORM/ECO ═══
    // 管理员在仪表盘看到累计金额后, 用新钱包授权转账(见手动转账工具)
  }

  // ═══ 链上自动转账算力费(实时到账): 每次扣费后立即用Trader私钥转账到管理员两钱包 ═══
  // PLATFORM_WALLET(平台费20%) + ECO_FUND_WALLET(生态费10%)
  async _tryTransferFees() {
    try {
      const feeFile = path.join(__dirname, '..', 'data', 'quant-fee-state.json');
      if (!require('fs').existsSync(feeFile)) return;
      const st = JSON.parse(require('fs').readFileSync(feeFile,'utf8'));
      const totalPlatform = +(st.totalPlatform||0);
      const totalEco = +(st.totalEco||0);
      const totalFee = totalPlatform + totalEco;
      if (totalFee <= 0) return;   // 无待转费用
      // 用Trader私钥转账
      const { ethers } = require('ethers');
      const provider = new ethers.JsonRpcProvider('https://bsc-rpc.publicnode.com');
      const wallet = new ethers.Wallet(process.env.TRADER_PRIVATE_KEY || '', provider);
      const usdt = new ethers.Contract('0x55d398326f99059ff775485246999027b3197955', ['function transfer(address,uint256) returns (bool)','function balanceOf(address) view returns (uint256)'], wallet);
      const traderBal = await usdt.balanceOf(await wallet.getAddress()).catch(()=>BigInt(0));
      const needTotal = ethers.parseUnits(totalFee.toFixed(6), 18);
      if (BigInt(traderBal) < needTotal) {
        this._log(`⏸️ 算力费实时转账: Trader余额$${(Number(BigInt(traderBal))/1e18).toFixed(4)} 不足$${totalFee.toFixed(2)}, 本次跳过(下次盈利时再转)`);
        return;
      }
      const GAS = ethers.parseUnits('5','gwei');
      if (totalPlatform > 0) {
        const tx = await usdt.transfer('0xb6DEb31484353AdDaA5b6A105A2B758Df11bC28A', ethers.parseUnits(totalPlatform.toFixed(6),18), { gasPrice: GAS });
        await tx.wait();
        this._log(`✅ 平台费$${totalPlatform.toFixed(2)}已实时转账到管理员钱包 b6DEb...`);
      }
      if (totalEco > 0) {
        const tx = await usdt.transfer('0xeF87e7fD5f0ADC5de82e84Dc9300002D9aC8bD82', ethers.parseUnits(totalEco.toFixed(6),18), { gasPrice: GAS });
        await tx.wait();
        this._log(`✅ 生态费$${totalEco.toFixed(2)}已实时转账到管理员钱包 eF87e...`);
      }
      // 转账成功后清零累计
      st.totalPlatform = 0; st.totalEco = 0;
      require('fs').writeFileSync(feeFile, JSON.stringify(st, null, 2));
    } catch(e) { this._log(`❌ 算力费链上转账异常: ${e.message.slice(0,80)}`); }
  }

  getSummary() {
    const t = Math.max(1, this.closedHistory.length);
    const wins = this.closedHistory.filter(c => c.pnl > 0).length;
    // ═══ 三策略独立统计(MA7大道至简 / V4阿奇日线 / 布林震荡) ═══
    const ma7T = this.closedHistory.filter(c => c.strat === 'ma7');
    const v4T  = this.closedHistory.filter(c => c.strat === 'v4');
    const bollT= this.closedHistory.filter(c => c.strat === 'bollinger');
    const stratStat = (arr) => ({
      trades: arr.length,
      wins: arr.filter(c => c.pnl > 0).length,
      losses: arr.filter(c => c.pnl < 0).length,
      realizedPnl: +arr.reduce((a,c) => a + (c.pnl||0), 0).toFixed(2),
      winRate: arr.length ? Math.round(arr.filter(c => c.pnl > 0).length / arr.length * 100) : 0
    });
    return {
      wallet: this.wallet, isAdmin: this.isAdmin, isWhitelist: this.isWhitelist, balance: this.balance,
      totalEquity: +(this.totalWalletBalance || ((this.balance||0)+(this._unrealizedPnl||0))).toFixed(2),  // 总资金 = 币安合约账户总余额
      unrealizedPnl: +((this._unrealizedPnl||0)).toFixed(2),
      positionCount: Object.keys(this.positions).length,
      positions: Object.entries(this.positions).map(([s,p]) => ({ symbol: s, side: p.side, strategy: p.strategy, entryPrice: p.entryPrice, currentPrice: p.currentPrice, leverage: p.leverage })),
      trades: this.closedHistory.length, wins, losses: this.closedHistory.length - wins,
      realizedPnl: this.closedHistory.reduce((a,c) => a + (c.pnl||0), 0),
      // ═══ 币安真实30天已实现盈亏(与币安App实时同步) ═══
      realizedPnl30d: this._realizedPnl30d ? this._realizedPnl30d.total : null,
      pnl30dSource: 'binance-income',
      // 双策略独立统计 + 每次平仓记录
      strategyPnl: { ma7: stratStat(ma7T), v4: stratStat(v4T), bollinger: stratStat(bollT) },
      closedTrades: this.closedHistory.slice(0, 100),
    };
  }

  // ═══ ADX 计算(本地, 供市场闸门) ═══
  _adxLocal(raw, period=14) {
    const arr = toArray(raw);
    if (!Array.isArray(arr) || arr.length < period * 2) return 0;
    let plusDM=0, minusDM=0, tr=0;
    const start = arr.length - period;
    for (let i=start; i<arr.length; i++) {
      const up = +arr[i][1] - +arr[i-1][1];
      const down = +arr[i-1][2] - +arr[i][2];
      const h=+arr[i][1], l=+arr[i][2], pc=+arr[i-1][3];
      tr += Math.max(h-l, Math.abs(h-pc), Math.abs(l-pc));
      if (up>down && up>0) plusDM += up;
      else if (down>up && down>0) minusDM += down;
    }
    if (tr===0) return 0;
    const pdi = plusDM/tr*100, mdi = minusDM/tr*100;
    return Math.abs(pdi-mdi) / Math.max(pdi+mdi, 0.001) * 100;
  }

  // ═══ 实时市场健康闸门: 开仓前校验该币当下适不适合策略(根治假波动币) ═══
  // strat: 'trend'|'boll'; kl: K线(对象/原始数组均可)
  // 返回 null=通过可开; 返回字符串=不通过原因(禁开)
  _marketGate(strat, kl) {
    try {
      if (!kl || kl.length < 40) return null;
      const arr = toArray(kl);
      const closes = arr.map(k => +k[3]);
      const price = closes[closes.length-1];
      const adx = this._adxLocal(arr, 14) || 0;
      let atr = 0, n = 0;
      for (let i = arr.length - 14; i < arr.length; i++) {
        const h = +arr[i][2], l = +arr[i][3];
        if (i > 0) { const pc = +closes[i-1]; n++; atr += Math.max(h-l, Math.abs(h-pc), Math.abs(l-pc)); }
      }
      const atrPct = n ? (atr / n) / (price || 1) * 100 : 0;
      if (strat === 'trend') {
        if (adx < 15) return `市场闸门: ADX=${adx.toFixed(1)}<15无趋势禁开`;
        if (atrPct < 0.08) return `市场闸门: ATR波动${atrPct.toFixed(2)}%太低(死水)禁开`;
        // ═══ 均线排列真顺畅检查: 要求EMA7与EMA25有明显距离(>0.15%), 挡住真正缠绕/死水, 但不过度拦有方向的币(0.25%实测几乎全拦, 放宽到0.15%) ═══
        const e7 = this.trend._ema(closes, this.trend.fast);
        const e25 = this.trend._ema(closes, this.trend.mid);
        if (e7 != null && e25 != null) {
          const spread = Math.abs(e7 - e25) / (e25 || 1) * 100;
          if (spread < 0.15) return `市场闸门: 均线缠绕(EMA7=${e7.toFixed(4)} EMA25=${e25.toFixed(4)}, 差${spread.toFixed(2)}%<0.15%)无顺畅趋势禁开`;
        }
        return null;
      }
      if (adx >= 25) return `市场闸门: ADX=${adx.toFixed(1)}≥25单边非震荡禁开`;
      // 震荡(5m): 需 ATR 有来回空间(0.05%~0.8%, 适配5m单根波动小) - 原0.5%~6%按更长周期定, 5m全部被误拦
      if (atrPct < 0.05) return `市场闸门: ATR波动${atrPct.toFixed(2)}%<0.05%太窄(没来回)禁开`;
      if (atrPct > 0.8) return `市场闸门: ATR波动${atrPct.toFixed(2)}%>0.8%太剧烈禁开`;
      return null;
    } catch (e) { return null; }
  }

  // ═══ 大级别方向闸门(只留 EMA200 同向, 方案2: 保留更多开仓+防逆势): 返回禁开原因字符串(有值=禁开), null=通过 ═══
  // 回测: 只EMA200 开仓-12%(983→863)亏损-15%；双闸门砍38%(983→612)但亏损更多。用户选方案2只EMA200。
  async _trendAlignGate(symbol, sigSignal, klSmall) {
    try {
      // ── EMA200 同向闸门: LONG需价>=EMA200, SHORT需价<=EMA200 ──
      if (klSmall && klSmall.length >= 210) {
        const arr = toArray(klSmall);
        const closes = arr.map(k => +k[3]);
        const price = closes[closes.length - 1];
        const e200 = this.trend._ema(closes, 200);
        if (e200 != null) {
          const wantsLong = sigSignal === 'LONG';
          const above200 = price >= e200;
          if (wantsLong && !above200) return `逆EMA200(价${price.toFixed(4)}<EMA200 ${e200.toFixed(4)})禁多`;
          if (!wantsLong && above200) return `逆EMA200(价${price.toFixed(4)}>EMA200 ${e200.toFixed(4)})禁空`;
        }
      }
      return null;   // 通过
    } catch (e) { return null; }
  }
}

class QuantAgentManager {
  constructor(opts = {}) {
    this.adminApiKey = opts.apiKey || process.env.BINANCE_API_KEY || '';
    this.adminApiSecret = opts.apiSecret || process.env.BINANCE_API_SECRET || '';
    this.userDB = opts.userDB || null;
    this.intervalMs = opts.intervalMs || 60000;
    this._timer = null;
    this._agents = {};       // wallet → QuantAgent
    this.sharedMarket = new SharedMarket();  // ═══ 百万框架: 全局共享行情(所有用户共用1份K线/ticker, single-flight去重防重复拉API) ═══
    this._klineCache = this.sharedMarket._klineCache || {};  // 兼容旧引用
    this.signalMap = {};     // ═══ 十万并发阶段2: 全局共享开仓信号(symbol → {trend, bollSide, dirGate, t}) 首个用户算, 其他用户复用 ═══
    this.running = false;
    this.pauseOpen = false;
    this.pauseTrend = false;
    this.pauseV4 = true;          // ⛔ 只开新趋势策略(真趋势波段), V4禁止开仓
    this.pauseBoll = false;      // 暂停震荡(布林)开仓
    // ═══ 黑名单(禁区币) — 管理器层(选币/scan共用): ATOM高频秒仓连亏; STX贴EMA99被秒止损 ═══
    this.BLACKLIST = ['ATOMUSDT', 'STXUSDT', 'LITUSDT', 'INJUSDT'];
    // ═══ 角色区分 ═══
    // 管理员(唯一): fa3b90c5(0xfA3b90c574469909D20848273C06752a22fdE74a)
    this.ADMIN_WALLETS = ['0xfA3b90c574469909D20848273C06752a22fdE74a'];
    // 白名单(免算力费, 非管理员): e6ddf077/41c89c7d/c6dbb4cd等
    this.WHITELIST_WALLETS = ['0xe6ddf0771c7610dba77eb5a07ba7771dd7f5e91e','0x41c89c7df1ad4c8dd251c5afe45aa1c791fb6ea5','0xc6dbb4cd3b6a12068c7388248da2bd32df7ef9b7'];
    this.ALL_WALLETS = [...this.ADMIN_WALLETS, ...this.WHITELIST_WALLETS];
    // ═══ 交易池(分开配置) ═══
    // 震荡行情交易池(专门给 布林带震荡策略引擎 调用) — 布林回测精选优质币
    // WIF/FIL/ETH/APT/TURBO/STX 等(触轨低买高卖胜率高)
    // 震荡行情交易池(布林带引擎) — 修复NaN bug后最优回测精选(交易≥3+胜率100%)
    this.BOLLINGER_POOL = ['LINKUSDT','ORDIUSDT','SOLUSDT','OPUSDT','NEARUSDT','TONUSDT','SUIUSDT','AVAXUSDT','INJUSDT','LTCUSDT'];
    // ═══ 优选震荡币池(回测验证正期望14币, 只交易这些避免亏损山寨币): DOGE/ADA/INJ/IMX/SUI/ARB/DOT/XRP/ETH/SOL/LTC/APT/SEI/LINK ═══
    // v4(布林均值回归+SUPER): 回测验证核心3币池最优(胜率59%/+15.5%), 只用主流大市值币
    this.BOLL_PREFERRED = ['ETHUSDT','DOGEUSDT','INJUSDT','UNIUSDT'];  // v5: 15m盈利币池(剔除NEAR/APT)
    // 趋势行情交易池(给趋势策略引擎调用) — 30天趋势回测精选
    // 正期望: LINK/FIL(TIA/ADA等趋势弱负期望不纳入)
    // 趋势行情交易池(给趋势引擎调用) — v6摆动结构90天回测精选(胜率≥50%+正回报)
    // 趋势池(v7大道至简MA7·30天回测正期望精选): AVAX+5%/KAS+2.9%/TIA+1.5%/ADA+0.5%/BTC+0.4%
    this.TREND_POOL = ['AVAXUSDT','KASUSDT','TIAUSDT','ADAUSDT','BTCUSDT'];
    // ═══ 完全去池: 全市场每个币都实时尝试趋势信号(不再限定固定趋势池), 无信号才走布林 ═══
    this.COIN_POOL = [
      'BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT','LINKUSDT','LTCUSDT','DOTUSDT','UNIUSDT','APEUSDT','FILUSDT','NEARUSDT','ATOMUSDT','INJUSDT','OPUSDT','ARBUSDT','SUIUSDT','TIAUSDT','SEIUSDT','STXUSDT','KASUSDT','APTUSDT','WLDUSDT','ORDIUSDT','1000PEPEUSDT','JUPUSDT','PENDLEUSDT','HYPEUSDT','TAOUSDT','BCHUSDT','ENAUSDT','1000SHIBUSDT','AAVEUSDT','ONDOUSDT','TRUMPUSDT','XLMUSDT','1000BONKUSDT','LITUSDT'
    ];
    // ═══ 完全去池: 趋势池=全市场候选, 每个币都实时尝试趋势信号(不再限定固定趋势池) ═══
    this.TREND_POOL = [...this.COIN_POOL];
    this.MA7_POOL = [...this.COIN_POOL];   // MA7趋势池=全市场(每币实时判断)
    this.trendTop = [...this.COIN_POOL].slice(0,5);  // 排名Top币(开仓优先, 动态选币后更新)
    this.bollTop = [...this.COIN_POOL].slice(0,5);   // 震荡Top币
  }
  _log(m) { const ts = new Date().toLocaleString('sv-SE',{timeZone:'Asia/Shanghai'}); console.log(`[Quant] ${ts} ${m}`); }
  _isAdmin(w) { return this.ADMIN_WALLETS.some(a => a.toLowerCase() === (w||'').toLowerCase()); }
  _isWhitelist(w) { return this.WHITELIST_WALLETS.some(a => a.toLowerCase() === (w||'').toLowerCase()); }

  start() {
    if (this.running) return; this.running = true;
    this._log('🚀 新量化智能体管理器启动(市场分类+趋势/震荡双策略)');
    // ═══ 动态选币: 启动刷新一次 + 根据主流大盘(BTC)行情不定时自动重选 ═══
    this._refreshDynamicPool().catch(()=>{});
    this._lastPoolBTC = null;
    this._poolTimer = setInterval(() => this._checkBTCAndRefresh().catch(()=>{}), 15*60*1000);  // 每15分钟检测大盘, 变化才重选(不固定时间)
    this._loop();
  }

  // ═══ 根据主流大盘(BTC)行情不定时触发重选币 ═══
  // 当BTC日线趋势方向(UP/DOWN/FLAT)或波动发生变化时, 重新动态选币
  async _checkBTCAndRefresh() {
    try {
      const apiInst = new BinanceAPI(this.adminApiKey, this.adminApiSecret);
      const bkl = await apiInst.getKlines('BTCUSDT', '1d', 60).catch(() => null);
      if (!bkl || bkl.length < 40) return;
      const closes = bkl.map(k => +k.close);
      // BTC日线方向(近20日趋势方向)
      const seg = closes.slice(-20); let upN = 0; for (let i = 1; i < seg.length; i++) if (seg[i] > seg[i-1]) upN++;
      const ratio = upN / (seg.length - 1);
      const dir = ratio > 0.62 ? 'UP' : (ratio < 0.38 ? 'DOWN' : 'FLAT');
      const range = (Math.max(...seg) - Math.min(...seg)) / (Math.min(...seg) || 1);
      const state = dir + ':' + (range > 0.05 ? 'WIDE' : 'NARROW');
      // 大盘状态首次 或 与上次不同 → 重新选币(跟随时大盘变化)
      if (this._lastPoolBTC !== state) {
        this._log(`🧠 主流大盘BTC状态变化(${this._lastPoolBTC||'初'}→${state}), 触发重新选币`);
        this._lastPoolBTC = state;
        await this._refreshDynamicPool();
      } else {
        this._log(`🧠 大盘BTC状态不变(${state}), 暂不重选`);
      }
    } catch(e) { /* 忽略 */ }
  }

  async _loop() {
    try {
      // 读用户
      let users = {};
      try { users = JSON.parse(require('fs').readFileSync(path.join(__dirname,'..','data','saas-users.json'),'utf8')); } catch(e){}
      // 确保每个用户有智能体(管理员用统一key)
      for (const [wallet, u] of Object.entries(users)) {
        if (!wallet || !wallet.includes('0x')) continue;
        if (!this._agents[wallet]) {
          const isAdmin = this._isAdmin(wallet);
          const isWhitelist = this._isWhitelist(wallet);
          let apiKey, apiSecret;
          // 优先级: 用户有自己的key → 用独立key; 无key的管理员(fa3b90c5)用公用key
          if (u.binanceApiKey && u.binanceSecret) {
            apiKey = decrypt(u.binanceApiKey); apiSecret = decrypt(u.binanceSecret);
            if (!apiKey || apiKey.length !== 64) { if (!isAdmin && !isWhitelist) continue; apiKey=this.adminApiKey; apiSecret=this.adminApiSecret; }
          } else {
            if (!isAdmin && !isWhitelist) continue;
            if (isAdmin) { apiKey = this.adminApiKey; apiSecret = this.adminApiSecret; }
            else continue;  // 白名单无key不交易但保留
          }
          this._agents[wallet] = new QuantAgent({ wallet, apiKey, apiSecret, isAdmin, isWhitelist, userDB: this.userDB, pauseOpen: this.pauseOpen, sharedMarket: this.sharedMarket, signalMap: this.signalMap });
          const role = isAdmin ? '管理员' : (isWhitelist ? '白名单' : '普通');
          this._log(`${wallet.slice(0,10)} 智能体启动(${role})`);
        }
      }
      // 全部用户(普通+管理员/白名单)开放开仓, 按引擎统一的风控开关, 不再按角色强制暂停
      const agents = Object.values(this._agents);
      for (const a of agents) {
        // 所有用户统一按引擎全局开关 (不再强制非管理员暂停)
        a.pauseOpen = !!this.pauseOpen; a.pauseTrend = !!this.pauseTrend; a.pauseBoll = !!this.pauseBoll;
        if (a._logPauseOnce !== true && !a.isAdmin) { a._logPauseOnce = true; this._log(`ℹ️ 非管理员 ${a.wallet.slice(0,10)} 开仓权限: 按全局开关(不再强制暂停)`); }
        // ═══ 同步manager的池给agent(MA7/V4/布林各自独立池) + 排名Top ═══
        a.MA7_POOL = this.MA7_POOL; a.BOLLINGER_POOL = this.BOLLINGER_POOL; a.TREND_POOL = this.TREND_POOL; a.BOLL_PREFERRED = this.BOLL_PREFERRED;
        a.trendTop = this.trendTop || []; a.bollTop = this.bollTop || []; }
      // ═══ 排序后开仓: 先扫描排名Top的优质币, 再扫剩余池子(保证优质币优先占位) ═══
      const rankedPool = [ ...(this.trendTop || []), ...(this.COIN_POOL || []).filter(b => !(this.trendTop||[]).includes(b)) ];
      await Promise.all(agents.map(a => a.scan(rankedPool).catch(() => {})));
      this._log(`[循环] ${agents.length}个智能体 · 持仓${agents.reduce((s,a)=>s+Object.keys(a.positions).length,0)}`);
      // ═══ 持仓状况检查: 打印管理员各策略/接管仓分布(启动后可见) ═══
      for (const a of Object.values(this._agents)) {
        if (!a.isAdmin) continue;
        const pos = Object.values(a.positions || {});
        const trend = pos.filter(p=>p.strategy==='trend').length;
        const boll = pos.filter(p=>p.strategy==='bollinger').length;
        const ma7 = pos.filter(p=>p.strategy==='ma7').length;
        const managed = pos.filter(p=>p._managed).length;
        this._log(`📊 持仓检查[管理员]: 总${pos.length} (趋势${trend}/布林${boll}/MA7${ma7}/接管${managed})${pos.length>12?' ⚠️超9上限':''}`);
        for (const p of pos) { if(!p||!p.symbol) continue; this._log(`   ${p.symbol} ${p.side} ${p.strategy}${p._managed?'[接管]':''} 入@${p.entryPrice}` + (p._adoptGrace && Date.now()<p._adoptGrace ? ` ⏳宽限${Math.round((p._adoptGrace-Date.now())/60000)}分` : '')); }
      }
      // ═══ 趋势减弱提醒: 检测4h趋势从强变弱, 震荡策略可进场 ═══
      this._checkTrendWeakening().catch(()=>{});
    } catch(e) { this._log(`❌ 循环异常: ${e.message}`); }

    if (this.running) this._timer = setTimeout(() => this._loop(), this.intervalMs);
  }

  // ═══ 趋势减弱提醒: 每轮检测前5个币的4h趋势, 从强变弱时打日志提醒 ═══
  async _checkTrendWeakening() {
    try {
      const apiInst = new BinanceAPI(this.adminApiKey, this.adminApiSecret);
      const checkSyms = ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','DOGEUSDT'];
      let weakCount = 0;
      const ema = (list, n) => { const k = 2/(n+1); let e = list[0]; for(let i=1;i<list.length;i++) e=list[i]*k+e*(1-k); return e; };
      for (const sym of checkSyms) {
        const kl = await apiInst.getKlines(sym, '4h', 120).catch(()=>null);
        if (!kl || kl.length < 30) continue;
        const closes = kl.map(k => k.close);
        const e7 = ema(closes, 7), e25 = ema(closes, 25);
        const spread = Math.abs(e7 - e25) / (e25 || 1) * 100;
        if (spread <= 1.5) weakCount++;
      }
      // 趋势减弱：前5个币里有>=3个EMA差<1.5% → 市场进入震荡，震荡策略可大量进场
      if (weakCount >= 3 && this._lastTrendWeak !== true) {
        this._log(`🔔 趋势减弱提醒: ${weakCount}/5个币4h EMA差<1.5%, 市场进入震荡, 震荡策略可进场!`);
        this._lastTrendWeak = true;
      } else if (weakCount < 2 && this._lastTrendWeak === true) {
        this._log(`🔔 趋势恢复提醒: 只有${weakCount}/5个币趋势弱, 市场恢复单边趋势, 震荡策略谨慎!`);
        this._lastTrendWeak = false;
      }
    } catch(e) {}
  }

  setPauseOpen(v) { this.pauseOpen = !!v; for (const a of Object.values(this._agents)) a.pauseOpen = this.pauseOpen; }
  setPauseTrend(v) { for (const a of Object.values(this._agents)) a.pauseTrend = !!v; }

  // 分页拉K线(突破limit1500)
  async _pagKlines(api, sym, interval, count) {
    const out = []; const ms = { '5m':300000, '1h':3600000 }[interval] || 300000;
    let start = Date.now() - count * ms;
    while (out.length < count) {
      const kl = await api.getKlines(sym, interval, 1500).catch(() => null);
      if (!Array.isArray(kl) || !kl.length) break;
      out.push(...kl);
      // 用最后一根时间推进
      const lastT = kl[kl.length-1].time || kl[kl.length-1].openTime;
      const curMs = Date.now();
      if (lastT) start = lastT + ms; else break;
      if (kl.length < 1500) break;
    }
    return out;
  }

  // ═══ 大脑中枢·动态选币: 按当前市场+历史回测刷新趋势池/震荡池 ═══
  // 定时(默认6h)对候选币分别用趋势/布林策略回测, 选出最佳进对应池
  async _refreshDynamicPool() {
    try {
      this._log('🧠 动态选币开始...');
      const apiInst = new BinanceAPI(this.adminApiKey, this.adminApiSecret);
      const CANDIDATES = ['BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT','LINKUSDT','LTCUSDT','DOTUSDT','UNIUSDT','APEUSDT','FILUSDT','NEARUSDT','ATOMUSDT','INJUSDT','OPUSDT','ARBUSDT','SUIUSDT','TIAUSDT','SEIUSDT','STXUSDT','KASUSDT','APTUSDT','WLDUSDT','ORDIUSDT','1000PEPEUSDT','JUPUSDT','PENDLEUSDT','HYPEUSDT','TAOUSDT','BCHUSDT','ENAUSDT','1000SHIBUSDT','AAVEUSDT','ONDOUSDT','TRUMPUSDT','XLMUSDT','1000BONKUSDT','LITUSDT'];   // 补充适合布林带的主流流动性币(波动适中+流动性好)
      const trendPool=[], bollPool=[];
      for (const sym of CANDIDATES) {
        // ═══ 自动识别低波动横盘币并踢出(不手动拉黑) ═══
        const kld0 = await apiInst.getKlines(sym, '1d', 45).catch(()=>null);
        if (kld0 && kld0.length >= 40) {
          const c45 = kld0.map(k => +k.close);
          const win = c45.slice(-40);
          const amp = (Math.max(...win) - Math.min(...win)) / (Math.min(...win) || 1) * 100;  // 40日振幅%
          let up = 0; for (let i = 1; i < win.length; i++) if (win[i] > win[i-1]) up++;
          const ratio = up / (win.length - 1);
          // 低波动(振幅<8%) 且 无方向(占比42-58%) = 极窄死水横盘 → 自动踢出
          // (放宽: 原<12%+38-62%误杀BTC/AVAX等能走趋势的低波动大币, 收窄只剔真正死水)
          if (amp < 8 && ratio >= 0.42 && ratio <= 0.58) {
            // 加自动黑名单, 之后scan也跳过
            if (this.BLACKLIST && !this.BLACKLIST.includes(sym)) this.BLACKLIST.push(sym);
            this._log(`🚽 自动识别低波动横盘币踢出: ${sym} (40日振幅${amp.toFixed(0)}%, 方向${(ratio*100).toFixed(0)}%)`);
            continue;
          }
        }
        // 选币用5分钟级K线(近5天≈1440根, 加快选币; 震荡评估足够)
        const kl = await this._fetchKlinesM(sym, '5m', 1440, apiInst).catch(()=>null);
        if (!kl || kl.length < 900) continue;
        const basis = this._assessTrend(kl);              // 基础趋势强度分(保证所有币能排序)
        const tr = this._btTrend(kl);                     // 严格MA7真实回测收益
        // ═══ 核心: 真实回测亏损(ret<0)的币剔除(用户要求), 无样本(n<=0)用基础分, 正收益优先 ═══
        if (tr && tr.n > 0) {
          if (tr.ret > 0) trendPool.push({sym, ret: basis.ret + tr.ret, trRet: tr.ret});  // 真实盈利 → 基础分+奖励
          // 真实亏损(tr.ret<0) → 剔除, 不进趋势池
        } else {
          trendPool.push({sym, ret: basis.ret * 0.5, trRet: 0});   // 无回测样本(严格策略没成交) → 基础分减半排序, 不占奖励
        }
        const bo = this._btBoll(kl);   // 用最新截图版振荡(BollingerStrategy)真实回测
        // ═══ 截图一-2: 优先选'浮盈±≤1%'的温和币(近20根涨跌幅±1%内=价格平稳适合震荡高抛低吸) ═══
        let floatScore = 0;
        try {
          const cc = kl.map(x => +x.close);
          if (cc.length >= 21) {
            const g20 = (cc[cc.length-1]-cc[cc.length-21])/(cc[cc.length-21]||1)*100;
            if (Math.abs(g20) <= 1.0) floatScore = 0.5;   // 涨跌幅±1%内 → 加分(优先选)
          }
        } catch(e){}
        if (bo && bo.n > 0 && bo.ret > 0) bollPool.push({sym, ret: bo.ret + floatScore, boRet: bo.ret, floatScore});   // 优胜劣汰: 回测盈利才进震荡池 + 浮盈±1%偏好
        else if (floatScore > 0 && bo && bo.ret <= 0) bollPool.push({sym, ret: floatScore, boRet: bo.ret||0, floatScore});  // 浮盈±1%内但回测微亏也用基础分排入
      }
      trendPool.sort((a,b)=> b.ret - a.ret);
      bollPool.sort((a,b)=> b.ret - a.ret);
      const trendC = trendPool.slice(0,25);      // MA7候选(仅回测盈利)
      const bollC = bollPool.slice(0,25);        // 震荡候选
      // ═══ 分开选池: MA7趋势池(15m) 和 V4趋势池(日线) 各自独立 ═══
      const ma7Sym = trendC.map(x=>x.sym);       // MA7池 = 回测盈利币
      const newMA7 = ma7Sym.slice(0,25);
      // 震荡池: 从布林盈利候选剔除进入趋势池的币
      const allTrend = new Set(newMA7);
      const bollAll = bollPool.slice(0,50).filter(x=>!allTrend.has(x.sym)).map(x=>x.sym);
      const newBoll = bollAll.slice(0,25);
      // 只要趋势池或布林池任一有候选就更新
      if (newMA7.length>=1 && newBoll.length>=1) {
        // ═══ 完全去池: 趋势/布林都=全市场候选, 每个币实时判断策略 ═══
        this.COIN_POOL = [...CANDIDATES];
        this.TREND_POOL = [...this.COIN_POOL];
        this.MA7_POOL = [...this.COIN_POOL];
        this.BOLLINGER_POOL = [...this.COIN_POOL];
        // 排名靠前子集(开仓限)
        this.trendTop = newMA7.slice(0,5);
        this.bollTop = newBoll.slice(0,5);
        this._log(`🧠 动态选币 → MA7池${newMA7.length}只: ${newMA7.join(',')} | 震荡池${newBoll.length}只(≤20): ${newBoll.join(',')}`);
        this._log(`🟢 开仓限 → MA7 Top: ${this.trendTop.join(',')} | 震荡Top: ${this.bollTop.join(',')}`);
      }
    } catch(e){ this._log(`⚠️ 动态选币失败: ${e.message.slice(0,30)}`); }
  }
  // 趋势适配评估(用1h近30天): ADX高+有方向性 = 适合趋势策略
  // ═══ 动态选币: 分批拉取指定隔离数5m K线(绕过单次limit1500限制) ═══
  async _fetchKlinesM(symbol, interval, target, apiInst) {
    const out = [];
    let endTime = Date.now();
    while (out.length < target) {
      const q = `/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=1000&endTime=${endTime}`;
      const batch = await apiInst._get(q).catch(() => null);
      if (!batch || !batch.length) break;
      const mapped = batch.map(k => ({ time: k[0], open: parseFloat(k[1]), high: parseFloat(k[2]), low: parseFloat(k[3]), close: parseFloat(k[4]), volume: parseFloat(k[5]) }));
      const newOnes = mapped.filter(k => k.time < endTime);
      if (!newOnes.length) break;
      out.unshift(...newOnes.reverse());
      endTime = newOnes[0].time - 1;
      if (batch.length < 1000) break;
    }
    return out;
  }

  _assessTrend(kl){
    try{
      const c=kl.map(k=>+k.close); if(c.length<40)return {ret:-99,n:0,rate:0};
      let adxCnt=0, upCnt=0, dnCnt=0;
      const seg=c.slice(-60);
      const emaS=seg.slice(-7).reduce((a,b)=>a+b,0)/7, emaS2=seg.slice(-30).reduce((a,b)=>a+b,0)/30;
      const spread=Math.abs(emaS-emaS2)/(emaS2||1);
      // 用价格方向性: 近60根涨幅
      const chg=(c[c.length-1]-c[c.length-61])/(c[c.length-61]||1)*100;
      const dir=Math.abs(chg);
      return {ret: dir>10?dir*0.5:(dir>5?dir*0.3:dir*0.1), n: 1, rate: dir>8?100:(dir>5?60:40)};
    }catch(e){return {ret:-99,n:0,rate:0};}
  }
  // 震荡适配评估(用1h近30天): 波动小+区间稳定 = 适合布林震荡
  _assessBoll(kl){
    try{
      const c=kl.map(k=>+k.close); if(c.length<40)return {ret:-99,n:0,rate:0};
      const seg=c.slice(-60);
      const mx=Math.max(...seg),mn=Math.min(...seg);
      const rangePct=(mx-mn)/(mn||1)*100;
      // 震荡: 箱体稳定, 波动小
      return {ret: rangePct<20?30:(rangePct<35?15:5), n:1, rate: rangePct<25?80:(rangePct<40?65:45)};
    }catch(e){return {ret:-99,n:0,rate:0};}
  }

  // (保留原回测方法名兼容, 但用新评估)
  _btTrend(kl){
    try{
      const t=new TrendStrategy(); const c=kl.map(k=>+k.close); // 纯MA7趋势策略(与实盘一致)
      let pos=null,ret=0,n=0,w=0;
      const rel=kl.map(k=>({open:k.open,high:k.high,low:k.low,close:+k.close,volume:k.volume}));
      const arr=rel;
      for(let i=300;i<c.length;i++){
        const price=+arr[i].close,win=arr.slice(0,i+1),cl=win.map(x=>+x.close);
        if(pos){
          const lev=pos.side==='LONG'?5:3;
          const tp=t.takeProfit(pos,price,cl); let cr=null;
          if(tp.action==='CLOSE')cr='tp'; else{const s2=t.stopLoss(pos,price,cl);if(s2.action==='CLOSE')cr='sl';}
          if(cr){const raw=pos.side==='LONG'?(price-pos.entry)/pos.entry*100:(pos.entry-price)/pos.entry*100;const cp=raw*lev*0.15-0.001*0.15*200;ret+=cp;n++;if(cp>0)w++;pos=null;}
        } else { const sig=t.entrySignal(win,'FLAT'); if(sig.signal==='LONG'||sig.signal==='SHORT')pos={side:sig.signal,entry:price}; }
      }
      // 无真实回测成交(n=0): 不值得入选趋势池(可能是横盘/极端波动, 避免靠虚高得分塞币)
      if (n === 0) return { ret: -1, n: 0, rate: 0 };
      return {ret,n,rate:n?Math.round(w/n*100):0};
    }catch(e){return {ret:-99,n:0,rate:0};}
  }
  // 布林回测(1h近30天, 简化)
  _btBoll(kl){
    try{
      const b=new BollingerStrategy(); const arr=kl.map(k=>({open:k.open,high:k.high,low:k.low,close:+k.close,volume:k.volume}));
      const c=arr.map(x=>+x.close);
      let pos=null,ret=0,n=0,w=0;
      for(let i=60;i<c.length;i++){
        const price=+arr[i].close,win=arr.slice(0,i+1);
        const prev=c[i-1]; if(prev>0&&Math.abs(price-prev)/prev>0.03){continue;}
        if(pos){
          const tp=b.checkTakeProfit(pos,win); let cr=null;
          if(tp.action==='CLOSE')cr='tp'; else{const hs=b.checkHardStop(pos,win,0);if(hs.stop)cr='sl';}
          if(cr){const raw=pos.side==='LONG'?(price-pos.entry)/pos.entry*100:(pos.entry-price)/pos.entry*100;const cp=raw*3*0.15-0.001*0.15*200;ret+=cp;n++;if(cp>0)w++;pos=null;}
        } else { const g=b.canOpen(win); if(g.allowed){const es=b.entrySignal(win,'FLAT',false);if(es.signal==='LONG'||es.signal==='SHORT')pos={side:es.signal,entry:price};} }
      }
      return {ret,n,rate:n?Math.round(w/n*100):0};
    }catch(e){return {ret:-99,n:0,rate:0};}
  }

  // ═══ V4 阿奇日线大周期趋势回测(用于日线趋势精选池选币) ═══
  // 日线K线: 横盘不做/收盘站稳突破/回踩/逻辑止损/盈利让跑
  // V4已物理删除: 此回测函数不再使用, 返回空结果
  _btTrendV4Daily(kl){
    return {ret:0,n:0,rate:0};
  }

  // ═══ 当前趋势检测: 近N根日线是否正走单边趋势(UP/DOWN) 还是横盘(FLAT) ═══
  _trendV4Now(kl) {
    try {
      const c = kl.slice(-45).map(k => +k.close);
      if (c.length < 40) return 'FLAT';
      const ups = c.slice(-30).filter((_, i) => i > 0 && c.slice(-30)[i] > c.slice(-30)[i-1]).length;
      const ratio = ups / 29;   // 近30日上涨占比
      const seg = c.slice(-20);
      const amp = (Math.max(...seg) - Math.min(...seg)) / (Math.min(...seg) || 1);
      // 方向性(放宽: 占比>55%上 或 <45%下) + 振幅足(>5%) = 有趋势方向可入V4池
      if (ratio > 0.55 && amp > 0.05) return 'UP';
      if (ratio < 0.45 && amp > 0.05) return 'DOWN';
      return 'FLAT';
    } catch(e) { return 'FLAT'; }
  }

  getAllStatus() { return Object.values(this._agents).map(a => a.getSummary()); }
}

module.exports = { QuantAgentManager, QuantAgent };
