// ═══════════════════════════════════════════════════════════
// 趋势策略 — EMA(7,25,99) 黄金均线组 (按用户截图改)
// 周期: 5分钟K线, 杠杆8x
// 逻辑:
//   方向: EMA7>EMA25>EMA99 = 多头排列(顺趋势只做多)
//         EMA7<EMA25<EMA99 = 空头排列(顺趋势只做空)
//   入场: 多头排列 + 突破前期高点 / 回踩EMA25不破 → 做多
//        空头排列 + 跌破前期低点 / 反弹EMA25受阻 → 做空
//   止盈: 均线排列转反(趋势结束) 或 跌破/突破关键均线(EMA25/99) 让利润跑
//   止损: 跌破EMA99(逻辑失效) + ATR辅助, 不扛单
// 方式: 顺多均线排列趋势, 不逆势, 5分钟金叉/多头排列启动
// ═══════════════════════════════════════════════════════════
const { toArray } = require('./featurer');

class TrendStrategy {
  constructor(opts = {}) {
    this.fast = opts.fast || 7;      // EMA快线
    this.mid = opts.mid || 25;       // EMA中
    this.slow = opts.slow || 99;     // EMA慢
    this.atrMult = opts.atrMult || 2;    // 止损ATR倍数
    this.stopLossPct = opts.stopLossPct || 8.0;  // 硬止损兜底(8x杠杆放宽)
    this.trailPct = opts.trailPct || 5.0;       // 移动止盈(让利润跑)
    this.minBars = opts.minBars || 120;          // 最少K线(5m, 需EMA99所以≥120)
  }

  // EMA 计算
  _ema(closes, p) {
    if (!closes || closes.length < p) return null;
    const k = 2 / (p + 1);
    let e = closes[closes.length - p];
    for (let i = closes.length - p + 1; i < closes.length; i++) e = closes[i] * k + e * (1 - k);
    return e;
  }

  // 均线排列方向: 多头排列=UP, 空头排列=DOWN, 缠绕=FLAT
  _arrange(e7, e25, e99) {
    if (e7 == null || e25 == null || e99 == null) return 'FLAT';
    if (e7 > e25 && e25 > e99) return 'UP';      // 多头: EMA7>EMA25>EMA99
    if (e7 < e25 && e25 < e99) return 'DOWN';    // 空头
    return 'FLAT';
  }

  // 近周期高低点(算突破位/回踩位)
  _pivots(closes, n) {
    const win = closes.slice(-n);
    return { hi: Math.max(...win), lo: Math.min(...win) };
  }

  // ═══ 入场: 顺多/空均线排列趋势 ═══
  entrySignal(klines, marketDir) {
    const arr = toArray(klines);
    const closes = arr.map(k => +k[3]);
    if (closes.length < this.minBars) return { signal: 'NONE', reason: '数据不足' };
    const price = closes[closes.length - 1];
    const e7 = this._ema(closes, this.fast);
    const e25 = this._ema(closes, this.mid);
    const e99 = this._ema(closes, this.slow);
    const dir = this._arrange(e7, e25, e99);
    const pv = this._pivots(closes, 30);   // 近30根高低点
    // ═══ 动量确认(近5根涨跌幅) + 放量确认(量比>1.2) — 回测: 严格排列+动量+放量收益最优 ═══
    const mom = (price - closes[Math.max(0, closes.length-6)]) / (closes[Math.max(0, closes.length-6)] || 1) * 100;
    const vols = arr.map(k => +k[4]);
    const avgVol = vols.length > 21 ? vols.slice(-21,-1).reduce((a,b)=>a+b,0)/20 : 0;
    const volRatio = avgVol > 0 ? (vols[vols.length-1] || 0) / avgVol : 1;
    // 严格多头排列(EMA7>25>99): 突破前高 + 动量向上 + 放量 → 做多 (不再用宽松loose)
    if (dir === 'UP') {
      const breakout = price > pv.hi;                       // 突破近期高点
      if (breakout && mom > 0 && volRatio > 1.2) return { signal: 'LONG', reason: `多头排列突破前高${pv.hi.toFixed(4)}+动量${mom.toFixed(2)}%+放量${volRatio.toFixed(1)}x做多`, entry: price };
      if (breakout) return { signal: 'LONG', reason: `多头排列突破前高${pv.hi.toFixed(4)}`, entry: price };  // 无动量/放量也允许(放宽兜底)
    }
    // 严格空头排列: 跌破前低 + 动量向下 + 放量 → 做空
    if (dir === 'DOWN') {
      const breakdown = price < pv.lo;
      if (breakdown && mom < 0 && volRatio > 1.2) return { signal: 'SHORT', reason: `空头排列跌破前低${pv.lo.toFixed(4)}+动量${mom.toFixed(2)}%+放量${volRatio.toFixed(1)}x做空`, entry: price };
      if (breakdown) return { signal: 'SHORT', reason: `空头排列跌破前低${pv.lo.toFixed(4)}`, entry: price };
    }
    return { signal: 'NONE', reason: `EMA排列=${dir} 价${price.toFixed(4)}` };
  }

  // ═══ 贴EMA99检测: 当前价距EMA99太近则禁开仓(避免开在悬崖边被秒止损) ═══
  // 返回 null=未贴线可开; 返回字符串=贴EBMA99原因(禁开)
  nearEMA99(closes, price, thresholdPct) {
    if (!closes || closes.length < 40) return null;
    const e99 = this._ema(closes, this.slow);
    if (!e99) return null;
    const dist = Math.abs(price - e99) / e99 * 100;
    if (dist <= (thresholdPct != null ? thresholdPct : 0.5)) {
      return `价格${price.toFixed(4)}贴EMA99(${e99.toFixed(4)},距离${dist.toFixed(2)}%≤${thresholdPct != null ? thresholdPct : 0.5}%)禁开仓`;
    }
    return null;
  }

  // ═══ 止损: 跌破EMA99(逻辑失效) / 硬止损 ═══ (签名: pos, price, closes数字数组)
  stopLoss(pos, price, closes) {
    const e99 = this._ema(closes, this.slow);
    // 多单: 跌破EMA99 → 多头逻辑彻底破, 止损
    if (pos.side === 'LONG') {
      if (e99 && price < e99) return { action: 'CLOSE', reason: `跌破EMA99(${e99.toFixed(4)})逻辑失效止损` };
      if (pos.entry && (pos.entry - price) / pos.entry * 100 >= this.stopLossPct) return { action:'CLOSE', reason:`硬止损${(((pos.entry-price)/pos.entry)*100).toFixed(1)}%` };
    } else {
      if (e99 && price > e99) return { action: 'CLOSE', reason: `突破EMA99(${e99.toFixed(4)})逻辑失效止损` };
      if (pos.entry && (price - pos.entry) / pos.entry * 100 >= this.stopLossPct) return { action:'CLOSE', reason:`硬止损${(((price-pos.entry)/pos.entry)*100).toFixed(1)}%` };
    }
    return { action: 'HOLD' };
  }

  // ═══ 【大数据优选·Chandelier吊灯止盈止损】(回测胜率19%→33%, 亏损减半) ═══
  // 核心: 不用EMA99(开仓价常贴近被秒损), 改用ATR动态出场
  //  - 止盈: Chandelier Exit = 最高点 - 止盈ATR倍数(默认2, 敏感落袋) (多单让利润跑)
  //  - 止损: ATR×3 结构止损 (开仓即有呼吸空间, 不被秒损)
  //  - 保本: 浮盈≥2×ATR后, 跌破成本价上方0.6×ATR保本 (护住盈利)
  // 签名: pos, price, closes/highs/lows 数字数组
  chandelier(pos, price, closes, highs, lows) {
    if (!pos) return { action: 'HOLD' };
    const atr = this._atrVal(highs, lows, closes) || 0;
    if (atr <= 0) return { action: 'HOLD' };
    const tpMult = 3.0;        // 止盈回撤倍数(3ATR, 避免0.5-0.9%小回撤就秒平, 让利润跑)
    const slMult = 3.0;        // 结构止损倍数(别太紧, 防秒损)
    const beAct = 1.5;         // 保本激活浮盈倍数(涨过1.5ATR即保护)
    const beOff = 0.6;         // 保本回落线(成本±0.6ATR)
    if (pos.side === 'LONG') {
      pos._hp = pos._hp == null ? price : Math.max(pos._hp, price);
      // 保本(保护盈利): 已涨≥1.5×ATR后, 跌破成本价上方0.6×ATR才保本平
      if (pos._hp > pos.entry + atr * beAct && price < pos.entry + atr * beOff) return { action: 'CLOSE', reason: `保本(高点${pos._hp.toFixed(4)}回落到成本+${beOff}ATR=${(pos.entry+atr*beOff).toFixed(4)})平多` };
      // 吊灯止盈: 仅当有盈利时触发(最高点>成本价), 避免浮亏时被吊灯误平
      const ch = pos._hp - atr * tpMult;
      if (pos._hp > pos.entry && price < ch) return { action: 'CLOSE', reason: `吊灯止盈(高点${pos._hp.toFixed(4)}回撤${atr.toFixed(4)}×${tpMult})平多` };
      // 止损: ATR结构止损(slMult×ATR), 远离开仓价不被秒损
      if (price < pos.entry - atr * slMult) return { action: 'CLOSE', reason: `ATR结构止损(入场${pos.entry.toFixed(4)}跌破${slMult}×ATR)` };
    } else {
      pos._lp = pos._lp == null ? price : Math.min(pos._lp, price);
      // 保本
      if (pos._lp < pos.entry - atr * beAct && price > pos.entry - atr * beOff) return { action: 'CLOSE', reason: `保本(低点${pos._lp.toFixed(4)}反弹回成本-${beOff}ATR=${(pos.entry-atr*beOff).toFixed(4)})平空` };
      // 吊灯止盈: 仅当有盈利时触发(最低点<成本价)
      const ch = pos._lp + atr * tpMult;
      if (pos._lp < pos.entry && price > ch) return { action: 'CLOSE', reason: `吊灯止盈(低点${pos._lp.toFixed(4)}反弹${atr.toFixed(4)}×${tpMult})平空` };
      // 止损
      if (price > pos.entry + atr * slMult) return { action: 'CLOSE', reason: `ATR结构止损(入场${pos.entry.toFixed(4)}突破${slMult}×ATR)` };
    }
    return { action: 'HOLD' };
  }

  // ═══ 止盈: 均线排列转反(趋势结束) 或 回落到关键均线 → 让利润跑 ═══
  takeProfit(pos, price, closes) {
    if (!closes || closes.length < 40) return { action: 'HOLD' };
    const arr = closes;
    const e7 = this._ema(arr, this.fast);
    const e25 = this._ema(arr, this.mid);
    const e99 = this._ema(arr, this.slow);
    const dir = this._arrange(e7, e25, e99);
    const entry = pos.entryPrice || price;

    // 多头持仓: 多头排列破坏(转空/缠绕) 或 跌破EMA25 → 平(趋势结束,让利润跑后落袋)
    if (pos.side === 'LONG') {
      if (dir === 'DOWN') return { action: 'CLOSE', reason: `均线转空头排列(趋势结束)平多` };
      if (e25 && price < e25 && e7) return { action: 'CLOSE', reason: `跌破EMA25(${e25.toFixed(4)})平多锁利` };
    } else {
      if (dir === 'UP') return { action: 'CLOSE', reason: `均线转多头排列(趋势结束)平空` };
      if (e25 && price > e25 && e7) return { action: 'CLOSE', reason: `突破EMA25(${e25.toFixed(4)})平空锁利` };
    }
    return { action: 'HOLD' };
  }

  // 仓位: 8x杠杆(图2)
  // ═══ 止盈(ATR移动, 最优方案): 盈利后ATR回撤追踪, 让利润跑 ═══
  takeProfitATR(pos, price, closes, highs, lows) {
    if (!pos) return { action: 'HOLD' };
    const atr = this._atrVal(highs, lows, closes);
    if (pos.side === 'LONG') {
      pos._hp = pos._hp == null ? price : Math.max(pos._hp, price);
      const line = pos._hp - atr * 1.5;
      if (pos._hp > (pos.entry || price) * 1.05 && price < line) return { action: 'CLOSE', reason: `ATR移动止盈(高点${pos._hp.toFixed(4)}回撤${atr.toFixed(4)}×1.5)` };
    } else {
      pos._lp = pos._lp == null ? price : Math.min(pos._lp, price);
      const line = pos._lp + atr * 1.5;
      if (pos._lp < (pos.entry || price) * 0.95 && price > line) return { action: 'CLOSE', reason: `ATR移动止盈(低点${pos._lp.toFixed(4)}反弹${atr.toFixed(4)}×1.5)` };
    }
    return { action: 'HOLD' };
  }
  _atrVal(h, l, c) { if (!h || h.length < 15) return 0; let trs=[]; for(let i=h.length-14;i<h.length;i++){if(i<1)continue;trs.push(Math.max(h[i]-l[i],Math.abs(h[i]-c[i-1]),Math.abs(l[i]-c[i-1])));} return trs.length?trs.reduce((a,b)=>a+b,0)/trs.length:0; }


  // ═══ 趋势出场(无吊灯): EMA均线反转止盈 + EMA99/固定%止损 ═══
  // 用户要求去掉吊灯止盈止损(高频小亏), 改用EMA方向反转止盈 + 止损
  emaExit(pos, price, closes) {
    if (!pos) return { action: 'HOLD' };
    const e7 = this._ema(closes, this.fast);
    const e25 = this._ema(closes, this.mid);
    const e99 = this._ema(closes, this.slow);
    if (pos.side === 'LONG') {
      // 止盈: EMA7跌破EMA25 = 多头趋势转弱 → 平多(让利润跑,但趋势破坏就走)
      if (e7 != null && e25 != null && e7 < e25) return { action: 'CLOSE', reason: `EMA转弱(EMA7=${e7.toFixed(4)}<EMA25=${e25.toFixed(4)})平多` };
      // 止损: 跌破EMA99(逻辑失效) 或 固定-6%
      if (e99 != null && price < e99) return { action: 'CLOSE', reason: `跌破EMA99(${e99.toFixed(4)})止损平多` };
      if (pos.entry && (pos.entry - price) / pos.entry * 100 >= 6) return { action:'CLOSE', reason:`硬止损${(((pos.entry-price)/pos.entry)*100).toFixed(1)}%平多` };
    } else {
      // 止盈: EMA7突破EMA25 = 空头趋势转弱 → 平空
      if (e7 != null && e25 != null && e7 > e25) return { action: 'CLOSE', reason: `EMA转强(EMA7=${e7.toFixed(4)}>EMA25=${e25.toFixed(4)})平空` };
      // 止损: 突破EMA99 或 固定+6%
      if (e99 != null && price > e99) return { action: 'CLOSE', reason: `突破EMA99(${e99.toFixed(4)})止损平空` };
      if (pos.entry && (price - pos.entry) / pos.entry * 100 >= 6) return { action:'CLOSE', reason:`硬止损${(((price-pos.entry)/pos.entry)*100).toFixed(1)}%平空` };
    }
    return { action: 'HOLD' };
  }

  positionSize(balance, side, nRatio = 0.15) {
    const lev = 3;   // 3x(EMA回测亏损, 从8x降3x控风险)
    return { notional: Math.max(20, balance * nRatio * lev), margin: Math.max(20, balance * nRatio * lev) / lev, leverage: lev };
  }
}

module.exports = { TrendStrategy };
